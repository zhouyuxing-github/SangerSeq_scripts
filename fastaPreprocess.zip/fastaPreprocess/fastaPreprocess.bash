#!/bin/env bash
#####################################
# author:	"ZhouYuXing"                                                           #
# copyright:	"Copyright 2021, Southwest Minzu University"  #
# version:	"1.1"                                                                           #
# maintainer: "Zhouyuxing"                                                       #
# email: "1037782920@qq.com"                                                #
#####################################


while getopts 'i:a:h' arg
do
	case $arg in
		i)
			inFile="$OPTARG";;
		a)
			align="$OPTARG";;
		h)
			echo "Usage: `basename $0`  -i inFile.fas -a T"
			echo "if you want to conduct further alignment and phyloTree building, add:\"-a T\" "
			echo "This script is to preprocess the fastaFile(remove illegal characters and get sequence ids)"
			exit
	esac
done                                                                              #$OPTIND 特殊变量，option index，会逐个递增, 初始值为1；$OPTARG  特殊变量，option argument，不同情况下有不同的值
flag=0
if [ "$inFile" = "" ];
then
	echo "Usage: `basename $0`  -i inFile.fas -a T"
	flag=1
fi
if [ "$align" = "" ];
then
	echo "Usage: `basename $0`  -i inFile.fas -a T"
fi
if [ "$flag" = 1 ];
then
	echo  "Usage: `basename $0`  -i inFile.fas -a T"
	exit
fi
######     get bin directory    ######
SOURCE="$0"
while [ -h "$SOURCE"  ]; do # resolve $SOURCE until the file is no longer a symlink
    bin="$( cd -P "$( dirname "$SOURCE"  )" && pwd  )"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /*  ]] && SOURCE="$bin/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
bin="$( cd -P "$( dirname "$SOURCE"  )" && pwd  )"
#######         finished         #######
cat $inFile | tr -s ' ,:;\/()' '_' > ${inFile%.*}_preprocessed.fas && \
awk '/>/{print}' ${inFile%.*}_preprocessed.fas | sed 's/>//g' > ${inFile%.*}_id.xls && \
echo "Conguratu fking Lation! ${inFile%.*}_id.xls was generated!"
# 注意，bash的 if [ ]; then 返回的是T/F布尔值，如果不满足这两种情况，则会默认为T并走上这条分支
if [ "$align" != "" ];then
	echo "starting aligning using muscle at `date`..." && \
	time $bin/programs/muscle3.8.31_i86win32 -in ${inFile%.*}_preprocessed.fas -out ${inFile%.*}_aligned.fas && \
	echo "Alignment finnished at `date`, start constructing phylogenetic tree..." && \
	time $bin/programs/FastTree -nt ${inFile%.*}_aligned.fas > ${inFile%.*}_jc.nwk && \
	time $bin/programs/FastTree -nt -gtr ${inFile%.*}_aligned.fas > ${inFile%.*}_gtr.nwk && \
	time $bin/programs/FastTree  ${inFile%.*}_aligned.fas > ${inFile%.*}_jtt.nwk && \
	echo "All done at `date`, bye bye..." 
else
	echo "All done at `date`, bye bye..." 
fi
