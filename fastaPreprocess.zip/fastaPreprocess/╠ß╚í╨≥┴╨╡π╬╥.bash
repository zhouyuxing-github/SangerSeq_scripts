#!/bin/env bash
#####################################
# author:	"ZhouYuXing"                                                           #
# copyright:	"Copyright 2021, Southwest Minzu University"  #
# version:	"1.1"                                                                           #
# maintainer: "Zhouyuxing"                                                       #
# email: "1037782920@qq.com"                                                #
#####################################


while getopts 'n:i:h' arg
do
	case $arg in
		n)
			name="$OPTARG";;
		i)
			inFile="$OPTARG";;
		h)
			echo "Usage: `basename $0`  -n idNames.xls -i inFile.fasta"
			echo "This script is to extract sequences from the list"
			exit
	esac
done                                                                              #$OPTIND 特殊变量，option index，会逐个递增, 初始值为1；$OPTARG  特殊变量，option argument，不同情况下有不同的值
flag=0
if [ "$name" = "" ];
then
	echo "Usage: `basename $0`  -n idNames.xls -i inFile.fasta"
	flag=1
fi
if [ "$inFile" = "" ];
then
	echo "Usage: `basename $0`  -n idNames.xls -i inFile.fasta"
	flag=1
fi
if [ "$flag" = 1 ];
then
	echo  "Usage: `basename $0`  -n idNames.xls -i inFile.fasta"
	exit
fi
######     get bin directory    ######
SOURCE="$0"
while [ -h "$SOURCE"  ]; do # resolve $SOURCE until the file is no longer a symlink
    bin="$( cd -P "$( dirname "$SOURCE"  )" && pwd  )"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /*  ]] && SOURCE="$bin/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
bin="$( cd -P "$( dirname "$SOURCE"  )" && pwd  )"
#######         finished         #######
#注意，向awk中传参需要用 -v 来告诉电脑哪个是参数
sed -i '1i\id' $name # insert a row above
perl $bin/programs/fromContigsNameGetFasta.pl  $name  $inFile > ${inFile}_selected.fasta && \
echo "Conguratu fking lation! The ${inFile}_selected.fasta was generated!" && \
echo  " There are `awk '{if($0~/>/)print $0}' ${inFile}_selected.fasta | wc -l ` sequences extracted succesfully!"
