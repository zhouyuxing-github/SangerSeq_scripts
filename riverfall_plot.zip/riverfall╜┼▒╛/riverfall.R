# !/bin/Rscript
####################  sliding window  ###########################
args<-commandArgs(T)
setwd(args[1])
library(eoffice)
library(zoo)
data<-read.csv("merged.csv",header = F)
data_t<-t(data)
write.csv(data_t,file = "merged_t.csv")
data_t<-read.csv("merged_t.csv", header = T,row.names = 1,
                 colClasses = "character")
df<-data_t
for(i in 1:ncol(data_t)){
  df[,i] <- ifelse(data_t[,i]==data_t[,1],0,1)
}
df # df is final data for plotting

width=30 #50
step=1   #5
# function "eval()"，Execute a string as a command
for(i in 1:ncol(df)){
  str <- paste(colnames(df),'<-','rollapply(','df$',colnames(df),',FUN=sum,width=width,by=step)', sep='')
  print(str)
  eval(parse(text=str))
};print(str) # after execution，the Calculation results by slidingwindows were already assigned to V1、V2、V3……Vncol(df)
# plot the riverfall
par(mfrow=c(ncol(df),1),mar=c(0,2,0,0))
for(i in 1:ncol(df)){
  plot_cmd <- paste('plot(x=c(1:length(',colnames(df),')),y=',colnames(df),',type="o",cex=0,lwd=1.5,ylab="",ylim = c(0,17),xlab="",xaxt="n")')
  eval(parse(text=plot_cmd))
};print(plot_cmd)
text(x=0.5*nrow(df),y=10,labels = "amino mutations every 30AA, step:1AA",cex = 1.5)
topptx(filename = "riverfall.pptx")

