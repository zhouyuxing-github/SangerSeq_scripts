#!/bin/env bash
#################################################################################
# author:	"ZhouYuXing"																																													   #
# copyright:	"Copyright 2020, Southwest Minzu University"																													   #
# version:	"1.0"																																																	   #
# maintainer:	"Zhouyuxing"																																											   #
# email:	"fk your mamma@sina.cn" or  "1037782920@qq.com"																												   #
#################################################################################

bin="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
awk '/VERSION/||/country=/||/collection_date=/||/DEFINITION/||/host=/{print}'  $bin/sequence/sequence.gb | tr -s "\r\n "   "," | sed  's/VERSION,/\n>/g'  | sed 's/,\/country="/\t/g' | sed 's/,\/collection_date="/\t/g' |  sed 's/,\/host="/\t/g'  |sed 's/,\/lab_host="/\t/g' | sed 's/DEFINITION,/\t/g'   | sed 's/,/_/g' | sed 's/"//g' | sed 's/>//g' | tr -s "_" "_"  | sed 's/._$//g'  | sed 's/_/ /g'  > $bin/sequence/seqInfo.xls 
awk '/VERSION/||/country=/||/collection_date=/||/DEFINITION/{print}'  $bin/sequence/sequence.gb | tr -s "\r\n "   "," | sed  's/VERSION,/\n>/g' | sed 's/,\/country="/_|/g' | sed 's/,\/collection_date="/_|/g' | sed 's/DEFINITION,/_|/g' | sed 's/,/_/g' | sed 's/"//g' | sed 's/>//g' | tr -s "_" "_" | sed 's/\._$//g'  | sed  's/_|/|/g'  | sed  's/\.1|/.1_|/g' | sed  's/\.2|/.2_|/g'  | sed  's/\.3|/.3_|/g' | sed 's/_$//g'  > $bin/sequence/nameListWithInfo.xls
time perl  $bin/fromGenbankGetFasta.pl    $bin/sequence/nameListWithInfo.xls    $bin/sequence/sequence.fasta   >   $bin/sequence/seqWithInfo.fasta
rm $bin/sequence/nameListWithInfo.xls
echo "The fasta file with sampling Info was generated!"
echo "All Done! Bye Bye"










