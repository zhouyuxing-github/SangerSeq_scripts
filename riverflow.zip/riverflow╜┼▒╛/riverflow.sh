﻿#!/usr/bin/env bash
#################################################################################
# author:	"ZhouYuXing"						                                                                                                                                                 	           #
# copyright:	"Copyright 2021, Southwest Minzu University"	                                                                                                                           #
# version:	"1.0"								                                                                                                                                               	                       #
# maintainer:	"Zhouyuxing"							                                                                                                                                  	                       #
# email:	"1037782920@qq.com"	                                                                                                                                       	                                   #
#################################################################################


while getopts 'r:i:o:n:h' arg
do
	case $arg in
		i)
			inFile="$OPTARG";;
		h)
			echo "Usage: `basename $0`  -i AlignedProteins.fas "
			exit
	esac
done
bin="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$( dirname "$inFile" )"
flag=0
if [ "$inFile" = "" ];
then
	echo "Usage: `basename $0`  -i inFile.fas "
	flag=1
fi
if [ "$flag" = 1 ];
then
	echo  "Usage: `basename $0`  -i inFile.fas"
	exit
fi
# To pass parameters to awk, U need to use -v to tell the computer which parameters are
# split fasta
awk '/>/{close(p);++p}{print > p".fas1"}'  $inFile  && \
# rename
#for i in `ls *fas1`
#do
#{
#	newName=`head -1 $i | tr -s '/\ ,: '  '_' | sed 's/>//g' `
#	mv $i  ${newName%.*}.fas2
#}
#done  && \
# remove ">" line
for i in `ls *fas1`
do
{
	awk '/>/{getline;print}' $i
}> ${i%.*}.txt1
done  && \
for i in `ls *txt1`
do
{
	sed 's/A/A,/g' $i |sed 's/?/?,/g'|sed 's/-/-,/g'|sed 's/C/C,/g' |sed 's/D/D,/g' |sed 's/E/E,/g' |sed 's/F/F,/g' |sed 's/G/G,/g' |sed 's/H/H,/g' |sed 's/I/I,/g' |sed 's/K/K,/g' |sed 's/L/L,/g' |sed 's/M/M,/g' |sed 's/N/N,/g' |sed 's/P/P,/g' |sed 's/Q/Q,/g' |sed 's/R/R,/g' |sed 's/S/S,/g' |sed 's/T/T,/g' |sed 's/V/V,/g' |sed 's/W/W,/g' |sed 's/Y/Y,/g' |sed 's/*/*,/g' > ${i%.*}.txt2
}
done && \
#sort by file name
for i in `ls *txt2 |sort -n`
do
{
	cat $i
}>> merged_raw.csv
done
# Avoid confusion between Boolean "T" and "F" while reading csv in R
sed 's/T/t/g'  merged_raw.csv | sed 's/F/f/g' > merged.csv && \
rm *fas1 *txt1 *txt2 merged_raw.csv
# call Rscript in shell:  "/d/necessary_programs/R-3.6.1/bin/x64/Rscript.exe  myscript.R  arg1  arg2  arg3"
/d/necessary_programs/R-3.6.1/bin/x64/Rscript.exe  $bin/riverfall.R $bin
rm merged_t.csv


